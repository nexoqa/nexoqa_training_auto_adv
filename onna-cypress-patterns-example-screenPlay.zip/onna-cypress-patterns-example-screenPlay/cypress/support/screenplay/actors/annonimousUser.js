/**
Los actores nos permitirán definir y controlar los distintos stakeholders, tipos de usuarios
 quién interactuará con el sitio.

 Los actores pueden realizar tareas que describen las formas en que los usuarios interactúan.
*/

const { Actor } = require('cypress-screenplay');
module.exports = new Actor();