# onna-ejercicio

##  Patterns
- Data Builder: https://www.qwan.eu/2020/10/09/test-data-builders.html
- Circuit Breaker:
  <p align="center">
  <img src="images/circuit-breaker-seq.png" alt="circuit-breaker-seq"/>
  </p>
- Sidecar:
  <p align="center">
  <img src="images/sidecar.png" alt="sidecar"/>
  </p>
  
## Cypress
- Crear un test utilizando Cucumber + Cypress
  ```gherkin
  @connectors
  Feature: FilterBy

    Scenario: Initial view
      Given I'm at 'Home' page
      When I go to 'connectors' page
      Then I see 'View All' selected
      And I see all the connectors:
        | connectors                |
        | "amazon-web-services-aws" |
        | "box"                     |
        | "box-enterprise"          |

    # Scenario: Filter by AWS
    #   Given I'm at 'connectors' page
    #   When I'm in 'View All' filter
    #   And I type search word 'AWS'
    #   Then I can go to 'amazon-web-services-aws'
  ```
- Modificar el test para que cumpla el patrón PO
- Modificar el test para que cumpla el patrón ScreenPlay
- Publicar el proyecto en Jenkins

## Pact
Revisar https://www.hodler.co/2018/05/13/integration-tests-for-third-party-apis/

### Crear proyectos en GH
- __pact-python-provider__ a partir del ejercicio visto de PACT
- __pact-node-consumer__ (consumer de __pact-python-provider__) y completar el  _TODO_ en los ficheros que lo necesiten:
  - package.json:
    ```json
    "main": "index.js",
      "scripts": {
        "test": "rimraf pacts && mocha",
        "pact:publish": "pact-broker publish pacts --consumer-app-version='01' --broker-base-url=http://...",
      },
     "devDependencies": {
        "@pact-foundation/pact": "^9.16.0",
        "axios": "^0.21.1",
        "chai": "^3.5.0",
        "mocha": "^8.2.1",
        "rimraf": "^2.6.2"
      }
    ```

  - indexjs:
    ```js
      exports.getUserA = endpoint => {
        const url = endpoint.url
        const port = endpoint.port

        return axios.request({
          method: "GET",
          baseURL: `${url}:${port}`,
          url: "/users/UserA",
          headers: { Accept: "application/json" },
        })
      }
      ```
    - get-user.spec.js:
    ```js
    "use strict"

    const expect = require("chai").expect
    const path = require("path")
    const { Pact, Matchers  } = require("@pact-foundation/pact")
    const { getUserA } = require("../index")

    describe("The User API", () => {
      let url = "http://localhost"
      const port = 8992

      const { eachLike, like, uuid, iso8601DateTime, ipv4Address, boolean } = Matchers

      const provider = new Pact({
        port: port,
        log: path.resolve(process.cwd(), "logs", "mockserver-integration.log"),
        dir: path.resolve(process.cwd(), "pacts"),
        spec: 2,
        consumer: "UserServiceClient",
        provider: "UserService",
        pactfileWriteMode: "merge",
      })

      const EXPECTED_BODY = 
        {
          name: "UserA",
          id: "fc763eba-0905-41c5-a27f-3934ab26786c",
          ip_address: "127.0.0.1",
          admin:  false
        }

      // Setup the provider
      before(() => provider.setup())

      // Write Pact when all tests done
      after(() => provider.finalize())

      // verify with Pact, and reset expectations
      afterEach(() => provider.verify())

      describe("get /users/UserA", () => {
        before(done => {
          const interaction = {
            // TODO
          }
          provider.addInteraction(interaction).then(() => {
            done()
          })
        })

        it("returns the correct response", done => {
          const urlAndPort = {
            url: url,
            port: port,
          }
          getUserA(urlAndPort).then(response => {
            expect(response.data).to.eql(SAMPLE_BODY)
            done()
          }, done)
        })
      })
    })
     ```
## Jenkins
- Publicar en Jenkins  __pact-node-consumer__ y __pact-python-provider__
- Levantar Pact-Broker
